# HTTP Core Server

## Run
javac SimpleWebServer.java RequestParser.java
java SimpleWebServer

## Routes
GET /       -> Home
GET /login  -> Login
GET /admin  -> Admin

## Methods
GET, POST, HEAD supported

## POST Format
username=xxx&password=yyy
#########################
1. Unzip the folder
2. cd simple_server
3. javac SimpleWebServer.java RequestParser.java
4. java SimpleWebServer
5. Open browser:
   http://localhost:8080/
   http://localhost:8080/login
   http://localhost:8080/admin
6. POST test:
   curl -X POST -d "username=admin&password=123" http://localhost:8080

