import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;

public class SimpleWebServer {

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(8080);
            System.out.println("Server started on port 8080...");

            while (true) {
                Socket clientSocket = serverSocket.accept();

                BufferedReader in = new BufferedReader(
                        new InputStreamReader(clientSocket.getInputStream())
                );

                RequestParser request = new RequestParser(in);

                String method = request.getMethod();
                String path = request.getPath();

                String filePath = "www/index.html";

                if ("/login".equals(path)) filePath = "www/login.html";
                else if ("/admin".equals(path)) filePath = "www/admin.html";
                else if ("/favicon.ico".equals(path)) {
                    clientSocket.close();
                    continue;
                }

                if ("GET".equals(method) || "HEAD".equals(method)) {
                    byte[] fileData = Files.readAllBytes(Paths.get(filePath));

                    String header =
                            "HTTP/1.1 200 OK\r\n" +
                            "Content-Type: text/html; charset=UTF-8\r\n" +
                            "Content-Length: " + fileData.length + "\r\n" +
                            "\r\n";

                    clientSocket.getOutputStream().write(header.getBytes());

                    if ("GET".equals(method)) {
                        clientSocket.getOutputStream().write(fileData);
                    }
                }

                else if ("POST".equals(method)) {
                    String responseBody = "POST received: " + request.getBody();
                    String response =
                            "HTTP/1.1 200 OK\r\n" +
                            "Content-Type: text/plain; charset=UTF-8\r\n" +
                            "Content-Length: " + responseBody.getBytes().length + "\r\n" +
                            "\r\n" +
                            responseBody;

                    clientSocket.getOutputStream().write(response.getBytes());
                }

                clientSocket.close();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

