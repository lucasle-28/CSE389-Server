import java.io.BufferedReader;
import java.util.HashMap;
import java.util.Map;

public class RequestParser {

    private String method;
    private String path;
    private String version;
    private Map<String, String> headers = new HashMap<>();
    private String body = "";

    public RequestParser(BufferedReader reader) throws Exception {
        parse(reader);
    }

    private void parse(BufferedReader reader) throws Exception {
        String requestLine = reader.readLine();
        if (requestLine == null || requestLine.isEmpty()) return;

        String[] parts = requestLine.split(" ");
        method = parts[0];
        path = parts[1];
        version = parts[2];

        String line;
        while ((line = reader.readLine()) != null && !line.isEmpty()) {
            String[] headerParts = line.split(": ");
            if (headerParts.length == 2) {
                headers.put(headerParts[0], headerParts[1]);
            }
        }

        if ("POST".equals(method) && headers.containsKey("Content-Length")) {
            int length = Integer.parseInt(headers.get("Content-Length"));
            char[] buffer = new char[length];
            reader.read(buffer, 0, length);
            body = new String(buffer);
        }
    }

    public String getMethod() {
        return method;
    }

    public String getPath() {
        return path;
    }

    public String getVersion() {
        return version;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public String getBody() {
        return body;
    }
}

